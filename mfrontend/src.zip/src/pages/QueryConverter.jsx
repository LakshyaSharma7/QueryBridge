import React, { useState, useEffect } from 'react';
import ResultDisplay from '../components/ResultDisplay.jsx';

const QueryConverter = () => {
  const [query, setQuery] = useState('');
  const [sql, setSql] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState([]);

  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    try {
      const response = await fetch('http://localhost:5000/history');
      if (!response.ok) throw new Error('Failed to fetch history');
      const data = await response.json();
      setHistory(data);
    } catch (err) {
      console.error('Error fetching history:', err);
    }
  };

  const handleSubmit = async () => {
    if (!query.trim()) return;
    setError('');
    setSql('');
    setResult(null);
    setLoading(true);

    try {
      const response = await fetch('http://localhost:5000/parse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query }),
      });

      if (!response.ok) {
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      setSql(data.sql);
      setResult(data.results);
      fetchHistory(); // Refresh history after new query
    } catch (err) {
      setError('Failed to fetch SQL: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="query-converter">
      <h2 className="section-title">Natural Language to SQL</h2>

      <div className="input-group">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="e.g., age greater than 30"
          className="query-input"
          disabled={loading}
        />

        <button
          onClick={handleSubmit}
          className={`convert-button ${loading || !query.trim() ? 'disabled' : ''}`}
          disabled={loading || !query.trim()}
        >
          {loading ? 'Converting...' : 'Convert'}
        </button>
      </div>

      <ResultDisplay sql={sql} error={error} result={result} />

      <div className="query-history">
        <h3 className="history-title">Query History</h3>
        {history.length > 0 ? (
          <ul className="history-list">
            {history.map((item) => (
              <li key={item.id} className="history-item">
                <span>Query: {item.query_text}</span>
                <span>SQL: {item.generated_sql}</span>
                <span>Time: {new Date(item.generated_at).toLocaleString()}</span>
                {item.result && <pre>Result: {item.result}</pre>}
              </li>
            ))}
          </ul>
        ) : (
          <p className="no-history">No queries yet.</p>
        )}
      </div>
    </div>
  );
};

export default QueryConverter;